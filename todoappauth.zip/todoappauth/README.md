To-do app written in django framework


Instruction to run:

Open project folder

write this commands in terminal

pip3 install django // install django

python3 manage.py makemigrations base // make migrations

python3 manage.py migrate // run sql commands(migrations)

python3 manage.py runserver // run web server

open url written in terminal


